#!/bin/bash

rm FourierDescriptors_*.tar.gz
rm -rf FourierDescriptors.Rcheck
R CMD BUILD .
R CMD CHECK FourierDescriptors_*.tar.gz
R CMD INSTALL FourierDescriptors_*.tar.gz
