library('roxygen')

roxygenize('.', 'R',
           copy.package = FALSE,
           overwrite = FALSE,
           unlink.target = FALSE)

#file.move('R/man', 'man')
